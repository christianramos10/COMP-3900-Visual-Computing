﻿Public Class RectanglesForm

End Class