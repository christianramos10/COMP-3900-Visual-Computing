﻿Public Class CampusId

End Class