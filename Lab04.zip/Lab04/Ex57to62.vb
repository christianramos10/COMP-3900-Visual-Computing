﻿Public Class Ex57to62
    Private Sub btn_Click(sender As Object, e As EventArgs) Handles btn.Click
        numberTextBox.Text = "787"
        wordTextBox.Text = "Otorhinolaryngologist"
        maryLicensePlateTextBox.Text = "BHC365"
        caliLicensePlateTextBox.Text = "7BHC365"
        isbnTextBox.Text = "0-32-108599-X"
        abbTextBox.Text = "CA"
    End Sub
End Class