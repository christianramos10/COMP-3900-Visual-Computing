﻿Public Class Ex63to64
    Private Sub ButtonEx63_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Text = "Good Advice"
        textBox.Text = "First solve the problem. Then write code."
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Text = "Thanks Risks Proverb"
        textBox2.Text = "You can't stral second base and keep one foot on first."
    End Sub
End Class